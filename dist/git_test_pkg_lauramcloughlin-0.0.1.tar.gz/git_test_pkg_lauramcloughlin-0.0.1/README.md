# git_test_pkg

Pip install 
pip install -e git+git://github.com/lauramcloughlin/git_test_pkg.git#egg=git_test_pkg